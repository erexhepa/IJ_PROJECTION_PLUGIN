//INFO: null, 81707.50, 268661.43, 8691.18, 6880.52
//null, 59889.01, 252727.59, 10411.31, 8147.98
//null, 62061.80, 265764.37, 9687.05, 7604.78
//null, 65411.53, 277262.08, 8872.25, 8147.98
//null, 84876.16, 281245.54, 7514.25, 6789.99
//null, 76366.04, 256892.12, 8329.05, 6880.52
import qupath.lib.objects.*
import qupath.lib.roi.*
import qupath.lib.scripting.QPEx

// Any vertices
def x =  [59889.01, 62061.80,65411.53,84876.16,76366.04] as float[]
def y =  [252727.59, 265764.37, 277262.08, 281245.54, 256892.12 ] as float[]

def ellipseWidth = 5000

// Create object
def roi = new PolygonROI(x, y, -1, 0, 0)
def pathObject = new PathAnnotationObject(roi)

// Add object to hierarchy
addObject(pathObject)

print("Done 1!")

// Add ellipse region
// Any vertices
def xc=  59889.01 as double
def yc=  252727.59 as double  
def w =  ellipseWidth  as double
def h =  ellipseWidth  as double

// Create object
def roi2 = new EllipseROI( xc, yc,  w, h)
def pathObject2 = new PathAnnotationObject(roi2)

// Add object to hierarchy
addObject(pathObject2)


// This runs for img_mPAS_devel_PurpleClone
def file = new File('H:/SubversionDev/HISTOLOGY_DATA_ANALYSIS/testQuPath.txt')
def lines = file.readLines()

num_rois = lines.size/2

for (i = 0; i <num_rois; i++) {
    float[] x1 = lines[2*i].tokenize(',') as float[]
    float[] y1 = lines[2*i+1].tokenize(',') as float[]    
    
    
    // Create object
    def roiIter = new EllipseROI(x1[0] as double, y1[0] as double , 5000 as double, 5000 as double)
    //def pathObject = new PathDetectionObject(roi)
    def pathObject3 = new PathAnnotationObject(roiIter)
    // Add object to hierarchy
    addObject(pathObject3)
}

print("Numero de regions")
print num_rois

// Get the imageData & server
def imageData = QPEx.getCurrentImageData()
def server = imageData.getServer()

String path = server.getPath()
print path