import qupath.lib.scripting.QPEx

def objectMethods = Object.getMethods() as Set

def replacements = [
    'qupath.lib.scripting.QPEx.' : '',
    'qupath.lib.scripting.QP.' : '',
    'public static ' : '',
    'java.lang.': '',
    'java.io.File': 'File',
    'java.util.List': 'List',
    ',': ', '
]

def sb = new StringBuilder('Methods:\n')
for (m in QPEx.getMethods()) {
    if (m in objectMethods)
        continue
    def method = m.toString()
    for (entry in replacements.entrySet())
        method = method.replaceAll(entry.getKey(), entry.getValue())
    sb << method
    sb << '\n'
}
    
print sb

def imageData = QPEx.getCurrentImageData()
def server = imageData.getServer()

String path = server.getPath()
//print path
def strfname = path[path.lastIndexOf('\\')+1..-1]
print  strfname[0.. strfname.lastIndexOf('.')-1] 