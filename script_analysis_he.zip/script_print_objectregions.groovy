import qupath.lib.objects.classes.PathClass
import qupath.lib.objects.classes.PathClassFactory

def result = ''

for (annotation in getAnnotationObjects()) {
    def pathClass = annotation.getPathClass()
    print "test"
    def roi = annotation.getROI()
    result += String.format('%s, %.2f, %.2f, %.2f, %.2f',
        pathClass, roi.getBoundsX(), roi.getBoundsY(), roi.getBoundsWidth(), roi.getBoundsHeight())
    result += System.lineSeparator()
    
    print result
}

def GlomerulusClass = PathClassFactory.getPathClass("Immune cells")

def selected = getAnnotationObjects()
for (area in selected){area.setPathClass(GlomerulusClass)}