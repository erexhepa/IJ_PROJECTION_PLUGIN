import qupath.lib.scripting.QPEx
import qupath.lib.objects.*
import qupath.lib.roi.*

def imageData = QPEx.getCurrentImageData()
def server = imageData.getServer()
def radiusCirc = 9055

String path = server.getPath()
//print path
def strfname = path[path.lastIndexOf('\\')+1..-1]
def strfnameTrim =  strfname[0.. strfname.lastIndexOf('.')-1] 
def strpnameTrim =  path[0..path.lastIndexOf('\\')]
def coordFname = strpnameTrim+strfnameTrim + ".txt"

print coordFname

def file = new File(coordFname)
def lines = file.readLines()

num_rois = lines.size
print num_rois

for (i = 0; i <num_rois; i++) {
    float[] x1 = lines[i].tokenize(',') as float[]
    
    print x1[0]
    print x1[1]
    // Create object
    def roiIter = new EllipseROI((x1[0] as double)+4000, (x1[1] as double) +5000, radiusCirc as double, radiusCirc as double)
    //def pathObject = new PathDetectionObject(roi)
    def pathObject3 = new PathAnnotationObject(roiIter)
    // Add object to hierarchy
    addObject(pathObject3)
}

print("Numero de regions")
print num_rois
print  strfnameTrim + ".txt"
print strpnameTrim