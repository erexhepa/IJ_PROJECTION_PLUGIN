import qupath.lib.scripting.QPEx
import qupath.lib.objects.*
import qupath.lib.roi.*

selectAnnotations()
clearSelectedObjects(true)

selectDetections();
clearSelectedObjects(true)

def imageData = QPEx.getCurrentImageData()
def server = imageData.getServer()
def radiusCirc = 9055

String path = server.getPath()
//print path
def strfname = path[path.lastIndexOf('\\')+1..-1]
def strfnameTrim =  strfname[0.. strfname.lastIndexOf('.')-1] 
def strpnameTrim =  path[0..path.lastIndexOf('\\')]
def coordFname = strpnameTrim+strfnameTrim + ".txt"

print coordFname

def file = new File(coordFname)
def lines = file.readLines()

num_rois = lines.size
print num_rois

for (i = 0; i <num_rois; i++) {
    float[] x1 = lines[i].tokenize(',') as float[]
    
    print x1[0]
    print x1[1]
    // Create object
    def roiIter = new EllipseROI((x1[0] as double)+4000, (x1[1] as double) +5000, radiusCirc as double, radiusCirc as double)
    //def pathObject = new PathDetectionObject(roi)
    def pathObject3 = new PathAnnotationObject(roiIter)
    // Add object to hierarchy
    addObject(pathObject3)
}

print("Numero de regions")
print num_rois
print  strfnameTrim + ".txt"
print strpnameTrim

selectAnnotations();
runPlugin('qupath.imagej.detect.nuclei.WatershedCellDetection', '{"detectionImageBrightfield": "Hematoxylin OD",  "requestedPixelSizeMicrons": 0.5,  "backgroundRadiusMicrons": 8.0,  "medianRadiusMicrons": 1,  "sigmaMicrons": 1.5,  "minAreaMicrons": 10.0,  "maxAreaMicrons": 400.0,  "threshold": 0.1,  "maxBackground": 2.0,  "watershedPostProcess": true,  "cellExpansionMicrons": 5.0,  "includeNuclei": true,  "smoothBoundaries": true,  "makeMeasurements": true}');
removeMeasurements(qupath.lib.objects.PathCellObject, "Cell: Circularity", "Cell: Eccentricity", "Cytoplasm: Eosin OD mean", "Nucleus: Eosin OD range", "Nucleus: Eosin OD sum", "Nucleus: Eccentricity", "Cell: Max caliper", "Nucleus: Hematoxylin OD sum", "Nucleus: Eosin OD min", "Cell: Perimeter", "Cytoplasm: Eosin OD std dev", "Nucleus: Hematoxylin OD min", "Nucleus: Perimeter", "Nucleus: Hematoxylin OD range", "Cell: Eosin OD mean", "Nucleus: Circularity", "Nucleus: Eosin OD max", "Nucleus: Hematoxylin OD std dev", "Nucleus: Max caliper", "Nucleus: Hematoxylin OD max", "Cytoplasm: Eosin OD max", "Nucleus: Eosin OD std dev", "Cell: Eosin OD min", "Cell: Eosin OD std dev", "Nucleus: Eosin OD mean", "Nucleus/Cell area ratio", "Cell: Min caliper", "Nucleus: Area", "Cell: Eosin OD max", "Nucleus: Hematoxylin OD mean", "Cytoplasm: Eosin OD min", "Nucleus: Min caliper");

import qupath.lib.scripting.QPEx
import qupath.lib.objects.*
import qupath.lib.roi.*
 
imageData = QPEx.getCurrentImageData() 
server = imageData.getServer() 
radiusCirc = 9055

path = server.getPath()

//print path
strfname = path[path.lastIndexOf('\\')+1..-1]
strfnameTrim =  strfname[0.. strfname.lastIndexOf('.')-1]
outAnnoationsStatFname = "H://"+strfnameTrim+"_annotations.txt"
outDetectionsStatFname = "H://"+strfnameTrim+"_detections.txt"

saveAnnotationMeasurements( outAnnoationsStatFname)
saveDetectionMeasurements( outDetectionsStatFname)

selectAnnotations()
clearSelectedObjects(true)

selectDetections();
clearSelectedObjects(true)